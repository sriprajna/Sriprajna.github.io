# From completion to capability

## The business question
Did learning change anything meaningful at work?

## The measurement approach
Northstar starts with activity signals such as enrollment, completion, repeat visits, and practice. It then tests capability through assessment and skill progression, application through accuracy and speed, and business contribution through productivity, readiness, quality, mobility, or customer outcomes.

The analysis matures through four questions: what happened, why it happened, what is likely to happen, and what action should follow.

## What the snapshot says
Manager Essentials is the strongest scale signal because skill gain and performance lift move together. Data Fluency needs investigation: activity is healthy, but conversion trails the portfolio. Account executives are the clearest readiness intervention group.

## Measurement guardrails
The dashboard demonstrates correlation, timing, and contribution—not sole causation. Production use would require agreed definitions, role-based access, privacy controls, and trend analysis rather than one-time snapshots.

## Next decision
Protect the conversion gap with applied practice checkpoints and manager nudges, then recheck performance movement after 30 days.

## Reference
Metric concepts and the decision framework were informed by Disprz, “Learning Analytics: Definition, Metrics, Tools & ROI Measurement” (https://disprz.ai/blog/how-to-leverage-learning-analytics). This portfolio narrative and its fictional data are original.
