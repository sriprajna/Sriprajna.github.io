# Northstar Learning Analytics

A Power BI-inspired portfolio prototype showing how learning activity becomes capability and performance insight.

## Included
- `dashboard.html` — static snapshot suitable for a GitHub Pages link
- `case-study.md` — original supporting write-up and measurement approach
- `smart-art.svg` — learning analytics maturity model
- `sample-learning-analytics.csv` — realistic fictional program data

## Data note
This is fictional demo data. The AI insight is intentionally simulated and deterministic so the portfolio is transparent and reproducible.

## Content reference
Metric concepts and the decision framework were informed by Disprz, “Learning Analytics: Definition, Metrics, Tools & ROI Measurement” (https://disprz.ai/blog/how-to-leverage-learning-analytics). The case-study narrative and demo data are original.

## Suggested GitHub use
Publish `dashboard.html` with GitHub Pages, link to it from your profile README, and use `case-study.md` as the project narrative.
